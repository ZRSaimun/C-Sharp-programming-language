﻿//ZR Saimun
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PuzzelGame
{
    public partial class Form1 : Form
    {   
        public string num1 = null;
        public String num2 = null;

        public int sameButtonGroupCounter1 = 0;
        public int sameButtonGroupCounter2 = 0;

        public int clickcounter1 = 0;
        public int clickcounter2 = 0;



        double score = 0;
 
        public Form1()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, EventArgs e)
        {
           Button button = sender as Button;

            Button[] button1 = new Button[5] { btn1,btn2,btn3,btn7,btn8 }; 
            Button[] button2 = new Button[5] { btn11,btn22,btn33,btn77,btn88 };

            for (int i = 0; i < button1.Length; i++)
            {
                if (button.Name.Equals(button1[i].Name))
                {
                    clickcounter1++;
                    sameButtonGroupCounter1++;
                    if (sameButtonGroupCounter1 == 2)
                    {
                        //MessageBox.Show(Convert.ToString("num1=" + num1));
                        for (int j = 0; j < button1.Length; j++)
                        {
                            if (num1.Equals(button1[j].Text))
                            {
                                button1[j].ForeColor = Color.Yellow;
                              
                                score = score- 10;
                               // MessageBox.Show(Convert.ToString(score));
                                Score_Box.Text = Convert.ToString(score);
                            }
                        }
                        sameButtonGroupCounter1 = 0;
                        clickcounter1 = 0;
                        num1 = null;
                        num2 = null;
                    }
                    else
                    {
                        num1 = button1[i].Text;
                        button1[i].ForeColor = Color.Black;

                        //MessageBox.Show("num1=" + num1);
                    }
                }
            }

            for (int i = 0; i < button2.Length; i++)
            {
                if (button.Name.Equals(button2[i].Name))
                {
                    clickcounter2++;
                    sameButtonGroupCounter2++;
                    if (sameButtonGroupCounter2 == 2)
                    {
                       // MessageBox.Show(Convert.ToString("num2=" + num2));
                        for (int j = 0; j < button2.Length; j++)
                        {
                            if (num2.Equals(button2[j].Text))
                            {
                                button2[j].ForeColor = Color.Yellow;
                               
                                score = score - 10;
                                Score_Box.Text = Convert.ToString(score);

                            }
                        }
                        sameButtonGroupCounter2 = 0;
                        clickcounter2 = 0;
                        num1 = null;
                        num2 = null;
                    }
                    else
                    {
                        num2 = button1[i].Text;
                        button2[i].ForeColor = Color.Black;

                       // MessageBox.Show("num2" + num2);
                    }
                }
            }

                if (clickcounter1==1 && clickcounter2==1)
                {

                   // MessageBox.Show(Convert.ToString("clickcounter1=" + clickcounter1 + "\nclickcounter2=" + clickcounter2));
                   // MessageBox.Show("comparedddd");
                    if (num1.Equals(num2))
                    {
                        for (int x = 0; x < button1.Length; x++)
                        {
                            if (num1.Equals(button1[x].Text))
                            {
                                button1[x].Visible = false;
                            }
                        }
                        for (int y = 0; y < button2.Length; y++)
                        {
                            if (num1.Equals(button2[y].Text))
                            {
                                button2[y].Visible = false;
                            }
                        }

                    //MessageBox.Show("not null yet");
                    num1 = null;
                    num2 = null;
                    //MessageBox.Show("yes null");

                    }
                    else
                    {
                        for (int j = 0; j < button1.Length; j++)
                        {
                            if (num1.Equals(button1[j].Text))
                            {
                                button1[j].ForeColor = Color.Yellow;

                                score = score - 10;
                                Score_Box.Text = Convert.ToString(score);

                            }
                        }
                        for (int j = 0; j < button2.Length; j++)
                        {
                            if (num2.Equals(button2[j].Text))
                            {
                                button2[j].ForeColor = Color.Yellow;

                                score = score - 10;
                                Score_Box.Text = Convert.ToString(score);

                            }
                        }
                        //MessageBox.Show("not null yet");
                        num1 = null;
                        num2 = null;
                       // MessageBox.Show("yes null");

                    }
                    
                clickcounter1 = 0;
                clickcounter2 = 0;
                sameButtonGroupCounter1 = 0;
                sameButtonGroupCounter2 = 0;

                }
            //play again 
                if (btn1.Visible == false && btn11.Visible == false && btn2.Visible == false && btn22.Visible == false && btn3.Visible == false && btn33.Visible == false && btn7.Visible == false && btn77.Visible == false && btn8.Visible == false && btn88.Visible == false)
                {
                    PlayAgain pa = new PlayAgain();
                    pa.Visible = true;
                    this.Visible = false;
                }

        }


        private void Newbtn_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            score = Convert.ToDouble(Score_Box.Text);
         //   MessageBox.Show(Convert.ToString(score));
            Button button = sender as Button;

            Button[] button1 = new Button[10] { btn1, btn2, btn3, btn7, btn8, btn11, btn22, btn33, btn77, btn88 };
           

             int i;
             Random x = new Random();
             for (i = 0; i < 10; i++)
                {
                    Point pt = new Point
                      (
                            int.Parse(x.Next(700).ToString()),
                            int.Parse(x.Next(300).ToString())
                       );
        
                 button1[i].Location = pt;
          }
        

           
        }

        private void form_Close(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }




        
        
    }
}

