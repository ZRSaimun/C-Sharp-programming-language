﻿namespace PuzzelGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn1 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn22 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn33 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn77 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn88 = new System.Windows.Forms.Button();
            this.newbtn = new System.Windows.Forms.Button();
            this.Score = new System.Windows.Forms.Label();
            this.Score_Box = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Yellow;
            this.btn1.ForeColor = System.Drawing.Color.Yellow;
            this.btn1.Location = new System.Drawing.Point(32, 83);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(77, 77);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.Color.Yellow;
            this.btn11.ForeColor = System.Drawing.Color.Yellow;
            this.btn11.Location = new System.Drawing.Point(165, 83);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(77, 77);
            this.btn11.TabIndex = 1;
            this.btn11.Text = "1";
            this.btn11.UseVisualStyleBackColor = false;
            this.btn11.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.Yellow;
            this.btn2.ForeColor = System.Drawing.Color.Yellow;
            this.btn2.Location = new System.Drawing.Point(300, 83);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(77, 77);
            this.btn2.TabIndex = 2;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn22
            // 
            this.btn22.BackColor = System.Drawing.Color.Yellow;
            this.btn22.ForeColor = System.Drawing.Color.Yellow;
            this.btn22.Location = new System.Drawing.Point(419, 83);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(77, 77);
            this.btn22.TabIndex = 3;
            this.btn22.Text = "2";
            this.btn22.UseVisualStyleBackColor = false;
            this.btn22.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.Yellow;
            this.btn3.ForeColor = System.Drawing.Color.Yellow;
            this.btn3.Location = new System.Drawing.Point(541, 83);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(77, 77);
            this.btn3.TabIndex = 4;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn33
            // 
            this.btn33.BackColor = System.Drawing.Color.Yellow;
            this.btn33.ForeColor = System.Drawing.Color.Yellow;
            this.btn33.Location = new System.Drawing.Point(648, 83);
            this.btn33.Name = "btn33";
            this.btn33.Size = new System.Drawing.Size(77, 77);
            this.btn33.TabIndex = 5;
            this.btn33.Text = "3";
            this.btn33.UseVisualStyleBackColor = false;
            this.btn33.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.Yellow;
            this.btn7.ForeColor = System.Drawing.Color.Yellow;
            this.btn7.Location = new System.Drawing.Point(32, 166);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(77, 77);
            this.btn7.TabIndex = 6;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn77
            // 
            this.btn77.BackColor = System.Drawing.Color.Yellow;
            this.btn77.ForeColor = System.Drawing.Color.Yellow;
            this.btn77.Location = new System.Drawing.Point(156, 166);
            this.btn77.Name = "btn77";
            this.btn77.Size = new System.Drawing.Size(77, 77);
            this.btn77.TabIndex = 7;
            this.btn77.Text = "7";
            this.btn77.UseVisualStyleBackColor = false;
            this.btn77.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.Yellow;
            this.btn8.ForeColor = System.Drawing.Color.Yellow;
            this.btn8.Location = new System.Drawing.Point(264, 166);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(77, 77);
            this.btn8.TabIndex = 8;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn88
            // 
            this.btn88.BackColor = System.Drawing.Color.Yellow;
            this.btn88.ForeColor = System.Drawing.Color.Yellow;
            this.btn88.Location = new System.Drawing.Point(375, 166);
            this.btn88.Name = "btn88";
            this.btn88.Size = new System.Drawing.Size(77, 77);
            this.btn88.TabIndex = 9;
            this.btn88.Text = "8";
            this.btn88.UseVisualStyleBackColor = false;
            this.btn88.Click += new System.EventHandler(this.Button_Click);
            // 
            // newbtn
            // 
            this.newbtn.BackColor = System.Drawing.Color.DimGray;
            this.newbtn.ForeColor = System.Drawing.Color.White;
            this.newbtn.Location = new System.Drawing.Point(4, 370);
            this.newbtn.Name = "newbtn";
            this.newbtn.Size = new System.Drawing.Size(84, 37);
            this.newbtn.TabIndex = 10;
            this.newbtn.Text = "New Game";
            this.newbtn.UseVisualStyleBackColor = false;
            this.newbtn.Click += new System.EventHandler(this.Newbtn_Click);
            // 
            // Score
            // 
            this.Score.AutoSize = true;
            this.Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score.Location = new System.Drawing.Point(671, 3);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(59, 20);
            this.Score.TabIndex = 11;
            this.Score.Text = "Score: ";
            // 
            // Score_Box
            // 
            this.Score_Box.AutoSize = true;
            this.Score_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score_Box.Location = new System.Drawing.Point(736, 3);
            this.Score_Box.Name = "Score_Box";
            this.Score_Box.Size = new System.Drawing.Size(36, 20);
            this.Score_Box.TabIndex = 12;
            this.Score_Box.Text = "500";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 411);
            this.Controls.Add(this.Score_Box);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.newbtn);
            this.Controls.Add(this.btn88);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn77);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn33);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn22);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn11);
            this.Controls.Add(this.btn1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.form_Close);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn22;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn33;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn77;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn88;
        private System.Windows.Forms.Button newbtn;
        private System.Windows.Forms.Label Score;
        private System.Windows.Forms.Label Score_Box;
    }
}

