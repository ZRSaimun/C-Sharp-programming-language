﻿namespace Calculatorfinal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.button_c = new System.Windows.Forms.Button();
            this.button_on = new System.Windows.Forms.Button();
            this.button_1byx = new System.Windows.Forms.Button();
            this.off_Btn = new System.Windows.Forms.Button();
            this.button_root = new System.Windows.Forms.Button();
            this.button_square = new System.Windows.Forms.Button();
            this.button_equal = new System.Windows.Forms.Button();
            this.button_mul = new System.Windows.Forms.Button();
            this.button_plus = new System.Windows.Forms.Button();
            this.button_minus = new System.Windows.Forms.Button();
            this.button_ce = new System.Windows.Forms.Button();
            this.button_div = new System.Windows.Forms.Button();
            this.button_dot = new System.Windows.Forms.Button();
            this.text_box = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button1.Location = new System.Drawing.Point(4, 306);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 55);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button_click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button2.Location = new System.Drawing.Point(101, 306);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 55);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button_click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button3.Location = new System.Drawing.Point(198, 306);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 55);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button_click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button4.Location = new System.Drawing.Point(4, 245);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 55);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button_click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button5.Location = new System.Drawing.Point(101, 245);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(91, 55);
            this.button5.TabIndex = 7;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button_click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button6.Location = new System.Drawing.Point(198, 245);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(91, 55);
            this.button6.TabIndex = 6;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button_click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button7.Location = new System.Drawing.Point(4, 184);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(91, 55);
            this.button7.TabIndex = 5;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button_click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button8.Location = new System.Drawing.Point(101, 184);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(91, 55);
            this.button8.TabIndex = 4;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button_click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button9.Location = new System.Drawing.Point(198, 184);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(91, 55);
            this.button9.TabIndex = 11;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button_click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button0.Location = new System.Drawing.Point(4, 367);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(188, 51);
            this.button0.TabIndex = 10;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button_click);
            // 
            // button_c
            // 
            this.button_c.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button_c.Location = new System.Drawing.Point(295, 123);
            this.button_c.Name = "button_c";
            this.button_c.Size = new System.Drawing.Size(91, 55);
            this.button_c.TabIndex = 9;
            this.button_c.Text = "C";
            this.button_c.UseVisualStyleBackColor = false;
            this.button_c.Click += new System.EventHandler(this.button_click);
            // 
            // button_on
            // 
            this.button_on.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button_on.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button_on.Location = new System.Drawing.Point(392, 123);
            this.button_on.Name = "button_on";
            this.button_on.Size = new System.Drawing.Size(69, 55);
            this.button_on.TabIndex = 8;
            this.button_on.Text = "ON";
            this.button_on.UseVisualStyleBackColor = false;
            this.button_on.Click += new System.EventHandler(this.button_click);
            // 
            // button_1byx
            // 
            this.button_1byx.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_1byx.Location = new System.Drawing.Point(392, 246);
            this.button_1byx.Name = "button_1byx";
            this.button_1byx.Size = new System.Drawing.Size(69, 55);
            this.button_1byx.TabIndex = 15;
            this.button_1byx.Text = "1/x";
            this.button_1byx.UseVisualStyleBackColor = false;
            this.button_1byx.Click += new System.EventHandler(this.button_click);
            // 
            // off_Btn
            // 
            this.off_Btn.BackColor = System.Drawing.Color.Brown;
            this.off_Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.off_Btn.Location = new System.Drawing.Point(4, 123);
            this.off_Btn.Name = "off_Btn";
            this.off_Btn.Size = new System.Drawing.Size(91, 56);
            this.off_Btn.TabIndex = 14;
            this.off_Btn.Text = "OFF";
            this.off_Btn.UseVisualStyleBackColor = false;
            this.off_Btn.Click += new System.EventHandler(this.button_click);
            // 
            // button_root
            // 
            this.button_root.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_root.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.button_root.Location = new System.Drawing.Point(101, 124);
            this.button_root.Name = "button_root";
            this.button_root.Size = new System.Drawing.Size(91, 55);
            this.button_root.TabIndex = 13;
            this.button_root.Text = "√";
            this.button_root.UseVisualStyleBackColor = false;
            this.button_root.Click += new System.EventHandler(this.button_click);
            // 
            // button_square
            // 
            this.button_square.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_square.Location = new System.Drawing.Point(198, 123);
            this.button_square.Name = "button_square";
            this.button_square.Size = new System.Drawing.Size(91, 55);
            this.button_square.TabIndex = 12;
            this.button_square.Text = "X^2 ";
            this.button_square.UseVisualStyleBackColor = false;
            this.button_square.Click += new System.EventHandler(this.button_click);
            // 
            // button_equal
            // 
            this.button_equal.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_equal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.button_equal.Location = new System.Drawing.Point(392, 306);
            this.button_equal.Name = "button_equal";
            this.button_equal.Size = new System.Drawing.Size(69, 116);
            this.button_equal.TabIndex = 19;
            this.button_equal.Text = "=";
            this.button_equal.UseVisualStyleBackColor = false;
            this.button_equal.Click += new System.EventHandler(this.button_click);
            // 
            // button_mul
            // 
            this.button_mul.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_mul.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.button_mul.Location = new System.Drawing.Point(295, 246);
            this.button_mul.Name = "button_mul";
            this.button_mul.Size = new System.Drawing.Size(91, 55);
            this.button_mul.TabIndex = 18;
            this.button_mul.Text = "*";
            this.button_mul.UseVisualStyleBackColor = false;
            this.button_mul.Click += new System.EventHandler(this.button_click);
            // 
            // button_plus
            // 
            this.button_plus.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.button_plus.Location = new System.Drawing.Point(295, 367);
            this.button_plus.Name = "button_plus";
            this.button_plus.Size = new System.Drawing.Size(91, 55);
            this.button_plus.TabIndex = 17;
            this.button_plus.Text = "+";
            this.button_plus.UseVisualStyleBackColor = false;
            this.button_plus.Click += new System.EventHandler(this.button_click);
            // 
            // button_minus
            // 
            this.button_minus.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_minus.Font = new System.Drawing.Font("Minion Pro", 18.25F);
            this.button_minus.Location = new System.Drawing.Point(295, 306);
            this.button_minus.Name = "button_minus";
            this.button_minus.Size = new System.Drawing.Size(91, 55);
            this.button_minus.TabIndex = 16;
            this.button_minus.Text = "-";
            this.button_minus.UseVisualStyleBackColor = false;
            this.button_minus.Click += new System.EventHandler(this.button_click);
            // 
            // button_ce
            // 
            this.button_ce.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button_ce.Location = new System.Drawing.Point(392, 185);
            this.button_ce.Name = "button_ce";
            this.button_ce.Size = new System.Drawing.Size(69, 55);
            this.button_ce.TabIndex = 22;
            this.button_ce.Text = "CE";
            this.button_ce.UseVisualStyleBackColor = false;
            this.button_ce.Click += new System.EventHandler(this.button_click);
            // 
            // button_div
            // 
            this.button_div.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_div.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.button_div.Location = new System.Drawing.Point(295, 184);
            this.button_div.Name = "button_div";
            this.button_div.Size = new System.Drawing.Size(91, 55);
            this.button_div.TabIndex = 21;
            this.button_div.Text = "/";
            this.button_div.UseVisualStyleBackColor = false;
            this.button_div.Click += new System.EventHandler(this.button_click);
            // 
            // button_dot
            // 
            this.button_dot.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button_dot.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.button_dot.Location = new System.Drawing.Point(198, 365);
            this.button_dot.Name = "button_dot";
            this.button_dot.Size = new System.Drawing.Size(91, 55);
            this.button_dot.TabIndex = 20;
            this.button_dot.Text = ".";
            this.button_dot.UseVisualStyleBackColor = false;
            this.button_dot.Click += new System.EventHandler(this.button_click);
            // 
            // text_box
            // 
            this.text_box.BackColor = System.Drawing.Color.LightBlue;
            this.text_box.Location = new System.Drawing.Point(12, 32);
            this.text_box.Multiline = true;
            this.text_box.Name = "text_box";
            this.text_box.Size = new System.Drawing.Size(442, 57);
            this.text_box.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 453);
            this.Controls.Add(this.text_box);
            this.Controls.Add(this.button_ce);
            this.Controls.Add(this.button_div);
            this.Controls.Add(this.button_dot);
            this.Controls.Add(this.button_equal);
            this.Controls.Add(this.button_mul);
            this.Controls.Add(this.button_plus);
            this.Controls.Add(this.button_minus);
            this.Controls.Add(this.button_1byx);
            this.Controls.Add(this.off_Btn);
            this.Controls.Add(this.button_root);
            this.Controls.Add(this.button_square);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button_c);
            this.Controls.Add(this.button_on);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button_c;
        private System.Windows.Forms.Button button_on;
        private System.Windows.Forms.Button button_1byx;
        private System.Windows.Forms.Button off_Btn;
        private System.Windows.Forms.Button button_root;
        private System.Windows.Forms.Button button_square;
        private System.Windows.Forms.Button button_equal;
        private System.Windows.Forms.Button button_mul;
        private System.Windows.Forms.Button button_plus;
        private System.Windows.Forms.Button button_minus;
        private System.Windows.Forms.Button button_ce;
        private System.Windows.Forms.Button button_div;
        private System.Windows.Forms.Button button_dot;
        private System.Windows.Forms.TextBox text_box;
    }
}

