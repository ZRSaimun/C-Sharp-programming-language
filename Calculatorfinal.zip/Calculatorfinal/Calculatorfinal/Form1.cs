﻿//ZR Saimun
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculatorfinal
{
    public partial class Form1 : Form
    {
        public double result;
        public double number1;
        public double number2;
        public string operand;
        public int counter=0;
        public int operandCount = 0;

        public double secondNumber = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_click(object sender, EventArgs e)
        {
            Button button = sender as Button;

            
            ///
            if (button.Name.Equals("button1"))
            {
                text_box.Text += "1";
            }
            if (button.Name.Equals("button2"))
            {
                text_box.Text += "2";
            }
            if (button.Name.Equals("button3"))
            {
                text_box.Text += "3";
            }
            if (button.Name.Equals("button4"))
            {
                text_box.Text += "4";
            }
            if (button.Name.Equals("button5"))
            {
                text_box.Text += "5";
            }
            if (button.Name.Equals("button6"))
            {
                text_box.Text += "6";
            }
            if (button.Name.Equals("button7"))
            {
                text_box.Text += "7";
            }
            if (button.Name.Equals("button8"))
            {
                text_box.Text += "8";
            }
            if (button.Name.Equals("button9"))
            {
                text_box.Text += "9";
            }
            if (button.Name.Equals("button0"))
            {
                text_box.Text += "0";
            }
            if (button.Name.Equals("button_dot"))
            {
                text_box.Text += ".";
            }
            if (button.Name.Equals("button_on"))
            {
            Application.Restart();
            }
            if (button.Name.Equals("off_Btn"))
            {
                Application.Exit();
            }
            if (button.Name.Equals("button_1byx"))
            {
                number1 = Convert.ToDouble(text_box.Text);
                result = 1 / number1;
                text_box.Text = Convert.ToString(result);
                text_box.Text = "1" + "/" + number1 + "\r\n" + result;
            }
            if (button.Name.Equals("button_square"))
            {
                if (operandCount < 1)
                {
                    number1 = Convert.ToDouble(text_box.Text);
                    result = number1 * number1;
                    text_box.Text = Convert.ToString(result);
                    text_box.Text = number1 + "^" + "2" + "\r\n" + result;
                }
            }
            if (button.Name.Equals("button_root"))
            {
                if (operandCount < 1)
                {
                    //string[] s = text_box.Text.Split('√');
                    //text_box.Text += "0";
                    number1 = Convert.ToDouble(text_box.Text);
                    result = Math.Sqrt(number1);
                    text_box.Text = Convert.ToString(result);
                    text_box.Text = "√" + number1 + "\r\n" + result;
                }
            }
            if (button.Name.Equals("button_plus"))
            {

                if (operandCount < 1)
                {
                    text_box.Text += "+";
                    operand = "+";
                    operandCount++;
                    button_minus.Enabled = false;
                    button_mul.Enabled = false;
                    button_div.Enabled = false;
                }
                else
                {
                    operand = "+";
                    text_box.Text = Convert.ToString(result) + "+";
                   // button_minus.Enabled = false;
                   // button_mul.Enabled = false;
                    //button_div.Enabled = false;
                }
            }
            if (button.Name.Equals("button_minus"))
            {
                if (operandCount < 1)
                {
                    text_box.Text += "-";
                    operand = "-";
                    operandCount++;
                    button_plus.Enabled = false;
                    button_mul.Enabled = false;
                    button_div.Enabled = false;
                }
                else
                {
                    operand = "-";
                    text_box.Text = Convert.ToString(result) + "-";
                  //  button_plus.Enabled = false;
                  //  button_mul.Enabled = false;
                   // button_div.Enabled = false;
                }
            }
            if (button.Name.Equals("button_mul"))
            {
                if (operandCount < 1)
                {
                    text_box.Text += "*";
                    operand = "*";
                    operandCount++;
                    button_plus.Enabled = false;
                    button_minus.Enabled = false;
                    button_div.Enabled = false;
                }
                else
                {
                    operand = "*";
                    text_box.Text = Convert.ToString(result) + "*";
                //    button_plus.Enabled = false;
                 //   button_minus.Enabled = false;
                 //   button_div.Enabled = false;
                }
            }
            if (button.Name.Equals("button_div"))
            {
                if (operandCount < 1)
                {
                    text_box.Text += "/";
                    operand = "/";
                    operandCount++;
                    button_plus.Enabled = false;
                    button_mul.Enabled = false;
                    button_minus.Enabled = false;
                }
                else
                {
                    operand = "/";
                    text_box.Text = Convert.ToString(result) + "/";
                 //   button_plus.Enabled = false;
                  //  button_mul.Enabled = false;
                  //  button_minus.Enabled = false;
                }
            }
            //EQUAL_BUTTON
            if (button.Name.Equals("button_equal"))
            {
                counter++;
                if (counter<2)
                {
                    if (text_box.Text.Contains("+"))
                    {

                        string[] s = text_box.Text.Split('+');

                        number1 = Double.Parse(s[0]);
                        number2 = Double.Parse(s[1]);
                        secondNumber = number2;
                        // result = operation(number1, number2, operand);
                        result = number1 + number2;
                        text_box.Text = number1 + "+" + number2 + "\r\n" + Convert.ToString(result);
                        s[0] = null;
                        s[1] = null;

                    }
                    else if (text_box.Text.Contains("*"))
                    {
                        string[] s = text_box.Text.Split('*');

                        number1 = Double.Parse(s[0]);
                        number2 = Double.Parse(s[1]);
                        secondNumber = number2;

                        // result = operation(number1, number2, operand);
                        result = number1 * number2;
                        text_box.Text = number1 + "*" + number2 + "\r\n" + Convert.ToString(result);
                        s[0] = null;
                        s[1] = null;
                    }
                    else if (text_box.Text.Contains("/"))
                    {
                        string[] s = text_box.Text.Split('/');

                        number1 = Double.Parse(s[0]);
                        number2 = Double.Parse(s[1]);
                        secondNumber = number2;

                        // result = operation(number1, number2, operand);
                        result = number1 / number2;
                        text_box.Text = number1 + "/" + number2 + "\r\n" + Convert.ToString(result);
                        s[0] = null;
                        s[1] = null;
                    }
                    else
                    {
                        string[] s = text_box.Text.Split('-');

                        number1 = Double.Parse(s[0]);
                        number2 = Double.Parse(s[1]);
                        secondNumber = number2;

                        // result = operation(number1, number2, operand);
                        result = number1 - number2;
                        text_box.Text = number1 + "-" + number2 + "\r\n" + Convert.ToString(result);
                        s[0] = null;
                        s[1] = null;
                     }
                    button_plus.Enabled = true;
                    button_minus.Enabled = true;
                    button_mul.Enabled = true;
                    button_div.Enabled = true;

                }
                else
                {
                    if (operand.Equals("+"))
                    {
                        result += secondNumber;
                        text_box.Text = Convert.ToString(result);

                    }
                    else if(operand.Equals("-"))
                    {
                        result -= secondNumber;
                        text_box.Text = Convert.ToString(result);

                    }
                    else  if (operand.Equals("*"))
                    {
                        result *= secondNumber;
                        text_box.Text = Convert.ToString(result);

                    }
                    else if (operand.Equals("/"))
                    {
                        result /= secondNumber;
                        text_box.Text = Convert.ToString(result);

                    }
                }
                
            }
            
            if (button.Name.Equals("button_c"))
            {
                text_box.Text = "";
                result = 0;
                operandCount = 0;
                counter = 0;
                button_plus.Enabled = true;
                button_minus.Enabled = true;
                button_mul.Enabled = true;
                button_div.Enabled = true;
            }
            if (button.Name.Equals("button_ce"))
            {
                text_box.Text = text_box.Text.Remove(text_box.Text.Length - 1);
            }

        }


    }
}
